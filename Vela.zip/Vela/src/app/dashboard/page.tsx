"use client";
import { useState } from "react";
import Link from "next/link";

export default function Dashboard() {
  const [storeName, setStoreName] = useState("Vela.store");

  const floatingClothes = [
    "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=400&q=80",
    "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80",
    "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=400&q=80",
    "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&q=80",
  ];

  return (
    <div className="min-h-screen bg-[#FFFEF7] text-zinc-800 flex relative overflow-hidden">
      {/* Small color like homepage - Soft yellow */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute -top-[20%] -left-[15%] w-[600px] h-[600px] bg-[#FFD60A]/20 blur-[120px] rounded-full" />
        <div className="absolute top-[30%] -right-[15%] w-[500px] h-[500px] bg-[#FFC300]/15 blur-[120px] rounded-full" />
        <div className="absolute inset-0 bg-[#FFFEF7]/60" />

        {/* Floating - soft, not too bright */}
        <div className="absolute top-[10%] left-[4%] w-[130px] h-[170px] rounded-[18px] overflow-hidden shadow-[0_10px_24px_rgba(0,0,0,0.08)] border border-white/60 rotate-[-6deg] animate-[floatA_7s_ease-in-out_infinite] opacity-[0.55]">
          <img src={floatingClothes[0]} className="w-full h-full object-cover" alt="" />
        </div>
        <div className="absolute top-[55%] left-[3%] w-[140px] h-[180px] rounded-[18px] overflow-hidden shadow-[0_10px_24px_rgba(0,0,0,0.08)] border border-white/60 rotate-[4deg] animate-[floatB_8s_ease-in-out_infinite] opacity-[0.5]">
          <img src={floatingClothes[1]} className="w-full h-full object-cover" alt="" />
        </div>
        <div className="absolute top-[15%] right-[5%] w-[135px] h-[175px] rounded-[18px] overflow-hidden shadow-[0_10px_24px_rgba(0,0,0,0.08)] border border-white/60 rotate-[5deg] animate-[floatB_6.5s_ease-in-out_infinite] opacity-[0.55]">
          <img src={floatingClothes[2]} className="w-full h-full object-cover" alt="" />
        </div>
        <div className="absolute top-[60%] right-[4%] w-[130px] h-[170px] rounded-[18px] overflow-hidden shadow-[0_10px_24px_rgba(0,0,0,0.08)] border border-white/60 rotate-[-4deg] animate-[floatA_7.5s_ease-in-out_infinite] opacity-[0.5]">
          <img src={floatingClothes[3]} className="w-full h-full object-cover" alt="" />
        </div>
      </div>

      <style>{`
        @keyframes floatA { 0%,100%{transform:translateY(0px) rotate(-6deg)} 50%{transform:translateY(-14px) rotate(-4deg)} }
        @keyframes floatB { 0%,100%{transform:translateY(0px) rotate(4deg)} 50%{transform:translateY(-16px) rotate(6deg)} }
      `}</style>

      {/* Sidebar */}
      <aside className="w-[260px] bg-white/80 backdrop-blur-2xl border-r border-zinc-100 p-6 hidden md:flex flex-col relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-zinc-900 text-white flex items-center justify-center font-serif font-bold italic">V</div>
          <span className="font-serif italic text-[20px] text-zinc-900">vela</span>
          <span className="text-[9px] font-bold tracking-widest bg-[#FFD60A]/30 border border-[#FFD60A]/40 px-2 py-0.5 rounded-full text-zinc-900">LINK</span>
        </div>

        <div className="mt-10 space-y-1">
          <div className="px-3 py-2.5 rounded-xl bg-zinc-900 text-white text-[13px] font-semibold">Dashboard</div>
          <div className="px-3 py-2.5 rounded-xl text-zinc-500 text-[13px] font-medium hover:bg-zinc-50 cursor-pointer">Products</div>
          <div className="px-3 py-2.5 rounded-xl text-zinc-500 text-[13px] font-medium hover:bg-zinc-50 cursor-pointer">Outfits</div>
          <div className="px-3 py-2.5 rounded-xl text-zinc-500 text-[13px] font-medium hover:bg-zinc-50 cursor-pointer">Orders</div>
          <div className="px-3 py-2.5 rounded-xl text-zinc-500 text-[13px] font-medium hover:bg-zinc-50 cursor-pointer">Analytics</div>
        </div>

        <div className="mt-auto p-4 rounded-[16px] bg-[#FFFEF7] border border-zinc-200">
          <p className="text-[10px] font-bold tracking-widest text-zinc-400">YOUR LINK</p>
          <p className="mt-2 text-[13px] font-bold text-zinc-900">vela.link/{storeName}</p>
          <Link href="#" className="mt-3 flex h-8 rounded-full bg-zinc-900 text-white text-[12px] font-semibold items-center justify-center">View store</Link>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 relative z-10">
        <header className="h-[64px] bg-white/60 backdrop-blur-2xl border-b border-zinc-100 px-6 md:px-8 flex items-center justify-between">
          <h1 className="text-[15px] font-bold tracking-tight text-zinc-900">Good morning, Tolu</h1>
          <div className="flex items-center gap-2">
            <div className="h-8 px-3 rounded-full bg-white border border-zinc-200 text-[12px] font-semibold flex items-center text-zinc-700">Free plan</div>
            <Link href="#upgrade" className="h-8 px-4 rounded-full bg-zinc-900 text-white text-[12px] font-bold flex items-center">Upgrade</Link>
          </div>
        </header>

        <div className="p-6 md:p-8 max-w-[1100px]">
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white/80 backdrop-blur-xl border border-zinc-100 rounded-[20px] p-5 shadow-sm">
              <p className="text-[10px] font-bold tracking-widest text-zinc-400">TOTAL PRODUCTS</p>
              <p className="mt-3 text-[28px] font-extrabold tracking-tight text-zinc-900">12</p>
              <p className="mt-1 text-[12px] text-zinc-500 font-medium">5 on free plan</p>
            </div>
            <div className="bg-white/80 backdrop-blur-xl border border-zinc-100 rounded-[20px] p-5 shadow-sm">
              <p className="text-[10px] font-bold tracking-widest text-zinc-400">OUTFITS CREATED</p>
              <p className="mt-3 text-[28px] font-extrabold tracking-tight text-zinc-900">3</p>
              <p className="mt-1 text-[12px] text-zinc-500 font-medium">1 on free plan</p>
            </div>
            <div className="bg-white/80 backdrop-blur-xl border border-zinc-100 rounded-[20px] p-5 shadow-sm">
              <p className="text-[10px] font-bold tracking-widest text-zinc-400">STORE VIEWS</p>
              <p className="mt-3 text-[28px] font-extrabold tracking-tight text-zinc-900">1.2k</p>
              <p className="mt-1 text-[12px] text-emerald-600 font-semibold">+12% this week</p>
            </div>
          </div>

          <div className="mt-8 bg-white/80 backdrop-blur-xl border border-zinc-100 rounded-[20px] p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[14px] font-bold text-zinc-900">Store setup</p>
                <p className="text-[13px] text-zinc-500 font-medium mt-1">Your store link and details</p>
              </div>
              <div className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-[#FFD60A] text-black border border-black/10">60% complete</div>
            </div>
            <div className="mt-6 grid md:grid-cols-[1fr_auto] gap-4 items-end">
              <div>
                <label className="text-[10px] font-bold tracking-widest text-zinc-500">STORE NAME</label>
                <input value={storeName} onChange={e=>setStoreName(e.target.value)} className="mt-2 w-full h-11 px-4 rounded-xl border border-zinc-200 bg-white text-[14px] font-semibold text-zinc-900 focus:outline-none focus:ring-2 focus:ring-[#FFD60A]/30 focus:border-[#FFD60A]" />
              </div>
              <div className="h-11 px-6 rounded-xl bg-zinc-900 text-white text-[13px] font-bold flex items-center justify-center cursor-pointer">Save</div>
            </div>
          </div>

          <div className="mt-8">
            <div className="flex items-center justify-between">
              <p className="text-[14px] font-bold text-zinc-900">Recent products</p>
              <Link href="#" className="text-[12px] font-semibold text-zinc-500 hover:text-black">View all</Link>
            </div>
            <div className="mt-4 grid md:grid-cols-3 gap-4">
              {[1,2,3].map(i=>(
                <div key={i} className="bg-white/80 backdrop-blur-xl border border-zinc-100 rounded-[20px] overflow-hidden hover:border-zinc-200 transition shadow-sm">
                  <div className="h-[180px] bg-zinc-50">
                    <img src={`https://images.unsplash.com/photo-${i===1 ? "1523381210434-271e8be1f52b" : i===2 ? "1516762689617-e1cffcef479d" : "1556821840-3a63f95609a7"}?w=400&q=80`} className="w-full h-full object-cover" alt="" />
                  </div>
                  <div className="p-4">
                    <p className="text-[13px] font-bold text-zinc-900">Vintage Tee {i}</p>
                    <p className="text-[12px] text-zinc-500 font-medium mt-1">₦15,000 • In stock</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}