"use client";
import Link from "next/link";
import { useEffect, useState } from "react";

export default function Home() {
  const [slide, setSlide] = useState(0);
  const [isNigeria, setIsNigeria] = useState(true);

  const looks = [
    { img: "https://images.unsplash.com/photo-1485968579580-b6d095142e6e?w=800&q=80", name: "Weekend Drip", tag: "3 items • Popular" },
    { img: "https://images.unsplash.com/photo-1516762689617-e1cffcef479d?w=800&q=80", name: "Street Essentials", tag: "Sneakers + Tee" },
    { img: "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=800&q=80", name: "Vintage Archive", tag: "Rare finds" },
    { img: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800&q=80", name: "Cruise Kit", tag: "Car + Fit combo" },
    { img: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&q=80", name: "Store Essentials", tag: "Bags + Accessories" },
    { img: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=800&q=80", name: "Clean Fit", tag: "Minimal look" },
  ];

  const floatingLeft = [
    "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=400&q=80",
    "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80",
  ];
  const floatingRight = [
    "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=400&q=80",
    "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&q=80",
    "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=400&q=80",
  ];

  useEffect(() => {
    const id = setInterval(() => setSlide(s => (s + 1) % looks.length), 5500);
    return () => clearInterval(id);
  }, [looks.length]);

  useEffect(() => {
    fetch("https://ipapi.co/json/").then(r=>r.json()).then(d=>setIsNigeria(d.country_code==="NG")).catch(()=>setIsNigeria(true));
  }, []);

  return (
    <main className="min-h-screen bg-[#FFFEF7] text-zinc-900 relative overflow-hidden">
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute -top-[20%] -left-[10%] w-[800px] h-[800px] bg-[#FFD60A]/30 blur-[130px] rounded-full" />
        <div className="absolute top-[40%] -right-[10%] w-[700px] h-[700px] bg-[#FFC300]/25 blur-[140px] rounded-full" />
        <div className="absolute top-[90px] left-[1%] hidden xl:flex flex-col gap-5 z-10">
          {floatingLeft.map((img,i)=>(
            <div key={i} className={`w-[180px] h-[230px] rounded-[24px] overflow-hidden shadow-[0_20px_40px_rgba(0,0,0,0.18)] border border-white/60 ${i===0 ? "animate-[floatA_7s_ease-in-out_infinite] rotate-[-6deg]" : "animate-[floatB_8s_ease-in-out_infinite] rotate-[4deg] ml-8"}`}>
              <img src={img} className="w-full h-full object-cover" alt="" />
            </div>
          ))}
        </div>
        <div className="absolute top-[140px] right-[1%] hidden xl:flex flex-col gap-5 z-10">
          {floatingRight.map((img,i)=>(
            <div key={i} className={`w-[170px] h-[210px] rounded-[24px] overflow-hidden shadow-[0_20px_40px_rgba(0,0,0,0.18)] border border-white/60 ${i===0 ? "animate-[floatB_6.5s_ease-in-out_infinite] rotate-[5deg]" : i===1 ? "animate-[floatA_7.5s_ease-in-out_infinite] rotate-[-4deg] mr-6" : "animate-[floatB_9s_ease-in-out_infinite] rotate-[3deg]"}`}>
              <img src={img} className="w-full h-full object-cover" alt="" />
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes floatA { 0%,100%{transform:translateY(0px) rotate(-6deg)} 50%{transform:translateY(-18px) rotate(-4deg)} }
        @keyframes floatB { 0%,100%{transform:translateY(0px) rotate(4deg)} 50%{transform:translateY(-22px) rotate(6deg)} }
        @keyframes kenBurns { 0%{transform:scale(1)} 100%{transform:scale(1.12)} }
        @keyframes progress{from{width:0%} to{width:100%}}
      `}</style>

      <div className="relative z-20">
        <nav className="h-[72px] bg-white/80 backdrop-blur-2xl border-b border-zinc-100 sticky top-0 z-50">
          <div className="max-w-[1200px] mx-auto px-6 h-full flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-black text-white flex items-center justify-center font-serif font-black italic">V</div>
              <span className="font-serif italic text-[24px] font-light">vela</span>
              <span className="ml-1 text-[10px] font-bold tracking-widest bg-[#FFD60A] px-2 py-1 rounded-full">LINK</span>
            </Link>
            <div className="flex items-center gap-2">
              <Link href="#pricing" className="hidden md:flex h-9 px-4 rounded-full bg-zinc-900/5 text-[13px] font-medium hover:bg-zinc-900/10 transition">Pricing</Link>
              <Link href="/dashboard" className="h-9 px-4 rounded-full bg-zinc-100 text-[13px] font-medium flex items-center hover:bg-zinc-200 transition">Sign in</Link>
              <Link href="/dashboard" className="h-10 px-5 rounded-full bg-black text-white text-[13px] font-bold flex items-center hover:bg-zinc-800 transition">Get started</Link>
            </div>
          </div>
        </nav>

        <section className="max-w-[1200px] mx-auto px-6 pt-14 md:pt-24 pb-16 grid md:grid-cols-[1.1fr_0.9fr] gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 h-7 px-3.5 rounded-full bg-[#FFD60A]/20 border border-[#FFD60A]/30 text-[11px] font-bold tracking-wide">
              <span className="w-1.5 h-1.5 bg-black rounded-full animate-pulse" /> NEW • BUILT FOR VENDORS WORLDWIDE
            </div>
            <h1 className="mt-6 text-[46px] md:text-[72px] font-[900] leading-[0.88] tracking-[-0.04em]">
              Your store,<br />
              <span className="font-serif italic font-light">sells itself.</span>
            </h1>
            <p className="mt-5 text-[17px] leading-[1.6] text-zinc-500 max-w-[460px]">
              Get your link <b className="text-black">vela.link/yourname</b>. Add your products. Customers swipe outfits and order straight on WhatsApp. Simple.
            </p>
            <div className="mt-8 flex gap-3">
              <Link href="/dashboard" className="h-[52px] px-7 rounded-full bg-black text-white font-bold text-[14px] flex items-center hover:bg-zinc-800 transition shadow-[0_10px_24px_rgba(0,0,0,0.18)]">Create your store free →</Link>
            </div>
            <div className="mt-6 flex items-center gap-3">
              <div className="flex -space-x-2">
                {[1,2,3,4].map(i=><img key={i} src={`https://i.pravatar.cc/100?img=${12+i}`} className="w-7 h-7 rounded-full border-2 border-white shadow-sm" alt="" />)}
              </div>
              <p className="text-[12px] text-zinc-500 font-medium">Loved by vendors worldwide • 2,000+ stores live</p>
            </div>
          </div>

          <div className="relative">
            <div className="absolute -top-5 -right-5 w-full h-full bg-[#FFD60A] rounded-[36px] rotate-2" />
            <div className="relative bg-white border border-zinc-200 rounded-[32px] p-3 shadow-[0_24px_80px_rgba(0,0,0,0.14)]">
              <div className="relative h-[520px] rounded-[22px] overflow-hidden bg-zinc-100">
                {looks.map((look, i) => (
                  <div key={i} className={`absolute inset-0 transition-all duration-[1600ms] ease-[cubic-bezier(0.4,0,0.2,1)] ${i===slide ? "opacity-100" : "opacity-0"}`}>
                    <img src={look.img} className={`w-full h-full object-cover ${i===slide ? "animate-[kenBurns_5.5s_ease-out_forwards]" : ""}`} alt="" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-5">
                      <div className="flex justify-between items-end">
                        <div>
                          <p className="text-white font-bold text-[20px] leading-none">{look.name}</p>
                          <p className="text-white/70 text-[12px] mt-1.5 font-medium">{look.tag}</p>
                        </div>
                        <div className="h-8 px-3 rounded-full bg-white text-black text-[12px] font-bold flex items-center">View look →</div>
                      </div>
                    </div>
                  </div>
                ))}
                <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-white/20">
                  <div key={slide} className="h-full bg-white animate-[progress_5.5s_linear]" />
                </div>
              </div>
              <div className="mt-4 flex justify-between items-center px-1">
                <div className="flex gap-1.5">
                  {looks.map((_,i)=><div key={i} className={`h-1.5 rounded-full transition-all duration-700 ${i===slide ? "w-8 bg-black" : "w-1.5 bg-zinc-300"}`} />)}
                </div>
                <p className="text-[11px] font-bold tracking-widest text-zinc-400">{slide+1} / {looks.length}</p>
              </div>
            </div>
          </div>
        </section>

        <section className="max-w-[1200px] mx-auto px-6 py-14 border-t border-zinc-100">
          <div className="flex items-center justify-between">
            <p className="text-[11px] font-bold tracking-[0.2em] text-zinc-400">TRUSTED WORLDWIDE</p>
            <p className="text-[11px] text-zinc-400"></p>
          </div>
          <div className="mt-6 grid md:grid-cols-3 gap-4">
            {[
              { name: "Tolu • Worldwide seller", text: "My customers now order full outfits. My average order value doubled since using Vela." },
              { name: "Amara • Fashion vendor", text: "Just dropped my vela.link on my status. Looks so professional, customers trust me more." },
              { name: "Daniel • Vintage store", text: "Cleanest store builder I have used. Setup took 60 seconds, no stress." },
            ].map(r=>(
              <div key={r.name} className="bg-white border border-zinc-200 rounded-[20px] p-5">
                <div className="flex gap-1 text-[#FFD60A] text-[14px]">★★★★★</div>
                <p className="mt-3 text-[14px] leading-relaxed text-zinc-700">"{r.text}"</p>
                <p className="mt-4 text-[12px] font-bold text-zinc-900">{r.name}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="pricing" className="max-w-[1200px] mx-auto px-6 py-16 border-t border-zinc-100">
          <h2 className="font-serif italic text-[38px] font-light">Simple pricing</h2>
          <p className="text-zinc-500 text-[14px] mt-2">Start free. Own it forever.</p>
          <div className="mt-8 grid md:grid-cols-2 gap-5 max-w-[820px]">
            <div className="rounded-[24px] bg-white border border-zinc-200 p-7">
              <p className="text-[11px] font-bold tracking-widest text-zinc-400">FREE</p>
              <p className="mt-3 text-[36px] font-black">₦0</p>
              <ul className="mt-6 space-y-2 text-[13px] text-zinc-600"><li>✓ 5 products</li><li>✓ 1 outfit</li><li>✓ WhatsApp orders</li></ul>
              <Link href="/dashboard" className="mt-8 flex h-11 rounded-full bg-zinc-100 items-center justify-center text-[13px] font-semibold hover:bg-zinc-200 transition">Start free</Link>
            </div>
            <div className="rounded-[24px] bg-black text-white p-7 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-[220px] h-[220px] bg-[#FFD60A]/20 blur-[50px] rounded-full" />
              <div className="relative">
                <p className="text-[11px] font-bold tracking-widest text-white/40">UNLIMITED • LIFETIME</p>
                <p className="mt-3 text-[42px] font-black leading-none">{isNigeria ? "₦6,500" : "$8"}</p>
                <p className="text-[12px] text-white/50 mt-1">Pay once, use forever</p>
                <ul className="mt-6 space-y-2 text-[13px] text-white/70"><li>✓ Unlimited products & outfits</li><li>✓ Remove branding</li><li>✓ Analytics</li></ul>
                <Link href="/dashboard" className="mt-8 flex h-12 rounded-full bg-white text-black items-center justify-center text-[14px] font-bold hover:bg-zinc-100 transition">Get Unlimited — {isNigeria ? "₦6,500" : "$8"}</Link>
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}